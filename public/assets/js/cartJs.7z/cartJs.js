'use strict'
var Cart = {
  orders: [],
  order:{},
  orderString:'',

  addOderItem:function(id,quantity){
    this.order[id] = quantity;
    this.orderToString();
  },

  orderToString:function(){
      var string = localStorage.getItem('command');
      var order;
      for(order in this.order){
        if(typeof(string) == "obecjt" ){
          string += order+'_'+this.order[order];
          console.log(string);
        }
        else{
          string += '|'+order+'_'+this.order[order];
        }

      }
      localStorage.setItem('command', string);
      // this.orderString = this.order+'*'+this.order.quantity+'|';
      // console.log(this.orderString);
  },

  orderToArray:function(){
    var string = localStorage.command.split('|');
        for(var i = 0 ; i < string.length - 1; i++){
          var str = string[i].split('_');
            this.orders.push(this.order[str[0]] = str[1]);
        }
        console.log(this.orders);

  },


}



$(document).ready(function(){
  var checkekCart = localStorage.getItem('command');
  if(typeof(checkekCart) !== "obecjt"){
      Cart.orderToArray();
  }
  else {

  }
});


$('input[name="order"]').on('click',function(){
    Cart.addOderItem($(this).attr('data-id'),$('#quantity :selected').text());
});
